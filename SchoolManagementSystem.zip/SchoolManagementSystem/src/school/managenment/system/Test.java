package school.managenment.system;

import java.util.ArrayList;
import java.util.List;


public class Test {

   public static void main(String[] args) {


        Teacher obj1=new Teacher(1,"vaibhav",5655.5f);
        Teacher obj2=new Teacher(2,"Tambe",654425.f);
          Teacher obj3=new Teacher(3,"Vaijapur",465.9f);
        List<Teacher> teacherList=new ArrayList<>();

        teacherList.add(obj1);
        teacherList.add(obj2);
        teacherList.add(obj3);


           Student s1=new Student(1,"vaibhav",4);
           Student s2=new Student(2,"Pradip",12);
           Student s3=new Student(3,"rushi",15);
           List<Student> studentList =new ArrayList<>();
           studentList.add(s1);
        studentList.add(s2);
        studentList.add(s3);

           School school1=new School(teacherList,studentList);

           Teacher obj4=new Teacher(6,"Sagar",6565655.5f);
           // school1.getTotalMoneyEarned();
        System.out.println("School has earned $ "+school1.getTotalMoneyEarned());

        s1.payFees(5000.0f);
        System.out.println("School has a earned "+school1.getTotalMoneyEarned());
        s2.payFees(5668.2f);
        System.out.println("School has a earned "+school1.getTotalMoneyEarned());


        System.out.println("Making pay salary to teachers");

         obj1.receiveSalary(obj1.getSalary());
        System.out.println("school has spent to teacher"+obj1.getName()+" and now more $ " +school1.getTotalMoneyEarned());

          //pay salary another teacher
        obj2.receiveSalary(school1.getTotalMoneyEarned());
        System.out.println("school has spent to teacher"+obj2.getName()+" and now more $ " +school1.getTotalMoneyEarned());

           //Student
        System.out.println(s1);

        //teacher
        obj1.receiveSalary(obj1.getSalary());
        System.out.println(obj1);

    }
}
