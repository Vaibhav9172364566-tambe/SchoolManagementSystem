package school.managenment.system;

/*
this class is responible for keeping the of teacher name ,id ,salary
 */
public class Teacher {
    private int id;
    private String name;
    private float salary;
    private  float salaryEarned;

    /*
    id is the for teacher
    name of the teacher
    salary of the teaher

     */
    public Teacher(int id, String name, float salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    //getter

    /*

     */


    public int  getId() {
        return id;
    }
    public String getName(){
        return name;

    }
    public float getSalary(){
        return salary;
    }

    //set the salary
    public void  setSalary(float salary){
        this.salary=salary;

    }

    public void add(Teacher teacher) {
    }
    public void receiveSalary(float salary){
        salaryEarned+=salary;
        School.updateTotalMoneySpent(salary);




    }
    @Override
    public String toString(){
        return " name of the Teacher "+name +" Total salary earned "+salaryEarned;
    }
}
