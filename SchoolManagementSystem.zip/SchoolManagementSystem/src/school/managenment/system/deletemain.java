package school.managenment.system;

import java.util.*;

public class deletemain {
    public static void main(String[] args)
    {
        //ArrayList-multiple numbers=define
        List<Float> number=new ArrayList<>();
        number.add(5f);
        number.add(32f);
        number.add(45f);
        number.add(6f);

        System.out.println(number);

    }

}
